/**
 * function to return rating for each movie as a whole number
 * @param {Array} ratings - Ratings Array in each movie from movies.json
 */
const getRating = (ratings) => {
  let total = 0;
  if (Array.isArray(ratings)) {
      ratings.forEach((rate) => {
          if ( rate.Value.indexOf('/') !== -1 ){
              const [left, right] = rate.Value.split('/');
              total += left / right;
          } else if ( rate.Value.indexOf('%') !== -1 ) {
              total += parseInt(rate.Value) / 100
          }
      });
      return Math.floor(total / ratings.length * 5);
  } else {
      return null;
  }
};
